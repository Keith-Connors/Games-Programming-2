﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace KeithConnors_LabTest1
{
    class Program
    {
        bool gameOver;
        bool creep;
        bool attack;
        bool move;
        bool shoot;

        static void Main(string[] args)
        {

        }
    }
}
